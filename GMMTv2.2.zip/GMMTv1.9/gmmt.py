"""
GMMT - Garry's Mod Motion Tracker (hub)

One window with a tab per tracker:
  Face     - webcam face / eyes / head   (face_tracker.py)
  Fingers  - webcam finger curl          (finger_tracker.py)
More tabs (body tracking, timeline render) will be added here later.

Install once:  py -m pip install mediapipe opencv-python numpy
Run:           py gmmt.py
Keep gmmt.py, face_tracker.py and finger_tracker.py in the same folder.

Note: a camera can only be used by one tracker at a time. To run face and
fingers together, give each tab a different camera number (for example a
phone used as a webcam).
"""
import os
import sys
import tkinter as tk
from tkinter import filedialog, ttk

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
_missing = [n for n in ("face_tracker.py", "finger_tracker.py")
            if not os.path.exists(os.path.join(HERE, n))]
if _missing:
    print("GMMT needs these files in the same folder as this script:")
    for n in _missing:
        print("   missing:", n)
    print("Folder checked:", HERE)
    print("Download them next to this file (they must be named exactly like that).")
    input("Press Enter to close...")
    sys.exit(1)

import face_tracker as ft
import finger_tracker as fg


class FingerTab:
    def __init__(self, root, parent, face_app, settings):
        self.root = root
        self.parent = parent
        self.face_app = face_app      # to share the data folder box
        self.settings = settings
        self.tracker = None
        self.photo = None
        self.last_png_id = 0

        pad = 12
        top = ttk.Frame(parent, padding=(pad, pad, pad, 0))
        top.pack(fill="x")

        left = ttk.Frame(top)
        left.pack(side="left", anchor="n")
        card = ft.App.card(face_app, left, "")
        card.pack()
        self.preview = tk.Label(card, bg="#0d0e11", fg=ft.MUTED, width=ft.PREVIEW_WIDTH // 8,
                                height=15, text="Camera preview\n(press Start)", justify="center",
                                font=("Segoe UI", 10))
        self.preview.pack()

        right = ttk.Frame(top)
        right.pack(side="left", anchor="n", padx=(pad, 0), fill="y")
        cam_card = ft.App.card(face_app, right, "Camera")
        cam_card.pack(fill="x")
        self.cam_var = tk.StringVar(value="Camera %d" % settings.get("finger_camera", 0))
        self.cam_box = ttk.Combobox(cam_card, textvariable=self.cam_var, state="readonly",
                                    values=["Camera %d" % i for i in range(6)], width=14)
        self.cam_box.pack(anchor="w")
        self.preview_var = tk.IntVar(value=1)
        ttk.Checkbutton(cam_card, text="Show preview", variable=self.preview_var,
                        command=self.on_preview).pack(anchor="w", pady=(8, 0))

        st = ft.App.card(face_app, right, "Status")
        st.pack(fill="x", pady=(10, 0))
        self.status = ttk.Label(st, text="Stopped", style="Card.TLabel", font=("Segoe UI", 11, "bold"))
        self.status.pack(anchor="w")
        self.detail = ttk.Label(st, text="Uses the garrysmod data folder from the Face tab.",
                                style="Muted.TLabel", wraplength=230, justify="left")
        self.detail.pack(anchor="w", pady=(4, 0))
        sm = ft.App.card(face_app, right, "Smoothing")
        sm.pack(fill="x", pady=(10, 0))
        self.smooth_var = tk.DoubleVar(value=settings.get("finger_smoothing", 0.5))
        ttk.Scale(sm, from_=0.0, to=1.0, variable=self.smooth_var, length=200,
                  command=lambda _v: self.on_smooth()).pack(anchor="w")
        ttk.Label(sm, text="left = quick, right = smoother", style="Muted.TLabel").pack(anchor="w")
        self.go = ttk.Button(right, text="Start tracking", style="Accent.TButton", command=self.toggle)
        self.go.pack(fill="x", pady=(10, 0))

        meters = ft.App.card(face_app, parent, "Finger curl (degrees)")
        meters.pack(fill="x", padx=pad, pady=pad)
        self.rows = {}
        grid = ttk.Frame(meters, style="Card.TFrame")
        grid.pack(fill="x")
        for c, name in enumerate(fg.FINGERS):
            ttk.Label(grid, text=name.title(), style="Head.TLabel").grid(row=0, column=c + 1, padx=6)
        for r, side in enumerate(("left", "right")):
            ttk.Label(grid, text=side.title(), style="Card.TLabel").grid(row=r + 1, column=0, sticky="w")
            for c, name in enumerate(fg.FINGERS):
                lab = ttk.Label(grid, text="-", style="Muted.TLabel", width=6)
                lab.grid(row=r + 1, column=c + 1, padx=6, pady=2)
                self.rows[(side, name)] = lab
        ttk.Label(meters, text="In Garry's Mod: open 'Finger Tracking' from the SMH tools strip. "
                  "To record, tick 'Nonphysical Bones' on a timeline.",
                  style="Muted.TLabel", wraplength=520, justify="left").pack(anchor="w", pady=(8, 0))

    def on_smooth(self):
        self.settings["finger_smoothing"] = round(self.smooth_var.get(), 2)
        if self.tracker:
            self.tracker.smoothing[0] = self.smooth_var.get()

    def on_preview(self):
        if self.tracker:
            self.tracker.preview_on[0] = bool(self.preview_var.get())

    def set_status(self, text, detail=None):
        self.status.configure(text=text)
        if detail is not None:
            self.detail.configure(text=detail)

    def toggle(self):
        if self.tracker and self.tracker.is_alive():
            self.stop()
            return
        path = self.face_app.dir_var.get().strip()
        if not os.path.isdir(path):
            self.set_status("Stopped", "Pick your garrysmod\\data folder on the Face tab first.")
            return
        try:
            camera = int(self.cam_var.get().split()[-1])
        except ValueError:
            camera = 0
        self.settings["finger_camera"] = camera
        self.tracker = fg.FingerTracker(camera, os.path.join(path, fg.OUTPUT_NAME))
        self.tracker.preview_on[0] = bool(self.preview_var.get())
        self.tracker.smoothing[0] = self.smooth_var.get()
        self.last_png_id = 0
        self.tracker.start()
        self.go.configure(text="Stop tracking", style="Stop.TButton")
        self.cam_box.configure(state="disabled")

    def stop(self):
        if self.tracker:
            self.tracker.stop()
            self.tracker.join(timeout=3)
        self.tracker = None
        self.go.configure(text="Start tracking", style="Accent.TButton")
        self.cam_box.configure(state="readonly")
        self.preview.configure(image="", text="Camera preview\n(press Start)",
                               width=ft.PREVIEW_WIDTH // 8, height=15)
        for lab in self.rows.values():
            lab.configure(text="-")
        self.set_status("Stopped", "")

    def poll(self):
        if self.tracker:
            snap = self.tracker.snapshot()
            if snap["status"] == "error":
                self.set_status("Problem", snap["message"])
                if not self.tracker.is_alive():
                    self.stop()
                    self.set_status("Problem", snap["message"])
            elif snap["status"] == "tracking":
                self.set_status("Tracking", "Sending to Garry's Mod.")
            elif snap["status"] == "nohands":
                self.set_status("No hands visible", "Hold your hands up in view of the camera.")
            else:
                self.set_status("Starting", snap["message"])
            if snap["png"] is not None and snap["png_id"] != self.last_png_id:
                self.last_png_id = snap["png_id"]
                try:
                    self.photo = tk.PhotoImage(data=snap["png"])
                    self.preview.configure(image=self.photo, text="", width=0, height=0)
                except tk.TclError:
                    pass
            for (side, name), lab in self.rows.items():
                v = snap["hands"].get(side, {}).get(name)
                lab.configure(text=("%d" % max(v)) if v else "-")

import json
import time
import phone_imu as pi


class PhoneTab:
    """Phone gyroscope (OSC over UDP) -> head rotation for the Face tracker."""

    CHOICES = ["Value 1 (+)", "Value 1 (-)", "Value 2 (+)", "Value 2 (-)", "Value 3 (+)", "Value 3 (-)"]

    def __init__(self, root, parent, face_app, settings):
        self.root, self.settings, self.face_app = root, settings, face_app
        self.imu = None
        pad = 12
        card = ft.App.card(face_app, parent, "Phone gyroscope")
        card.pack(fill="x", padx=pad, pady=(pad, 0))
        ttk.Label(card, text="Strap the phone to your head, install an app that sends OSC over Wi-Fi "
                  "(for example GyrOSC), and point it at this computer's IP address and the port below. "
                  "Your PC and phone must be on the same network.",
                  style="Muted.TLabel", wraplength=560, justify="left").pack(anchor="w")
        row = ttk.Frame(card, style="Card.TFrame")
        row.pack(fill="x", pady=(8, 0))
        ttk.Label(row, text="Port", style="Card.TLabel").pack(side="left")
        self.port_var = tk.StringVar(value=str(settings.get("phone_port", 5550)))
        ttk.Entry(row, textvariable=self.port_var, width=7).pack(side="left", padx=(6, 14))
        ttk.Label(row, text="OSC address", style="Card.TLabel").pack(side="left")
        self.addr_var = tk.StringVar(value=settings.get("phone_address", "/gyrosc/gyro"))
        ttk.Entry(row, textvariable=self.addr_var, width=16).pack(side="left", padx=(6, 14))
        self.rad_var = tk.IntVar(value=int(settings.get("phone_radians", 1)))
        ttk.Checkbutton(row, text="Angles are radians", variable=self.rad_var).pack(side="left")
        row2 = ttk.Frame(card, style="Card.TFrame")
        row2.pack(fill="x", pady=(8, 0))
        self.go = ttk.Button(row2, text="Start listening", style="Accent.TButton", command=self.toggle)
        self.go.pack(side="left")
        ttk.Button(row2, text="Recenter (look straight ahead)", command=self.recenter).pack(side="left", padx=8)
        self.use_var = tk.IntVar(value=int(settings.get("phone_use", 1)))
        ttk.Checkbutton(row2, text="Use phone for head rotation", variable=self.use_var,
                        command=self.apply_use).pack(side="left", padx=8)

        mp = ft.App.card(face_app, parent, "Which phone angle drives which head movement")
        mp.pack(fill="x", padx=pad, pady=(pad, 0))
        self.map_vars = {}
        grid = ttk.Frame(mp, style="Card.TFrame")   # the card already uses pack, so grid goes in its own frame
        grid.pack(fill="x")
        defaults = {"pitch": "Value 1 (+)", "yaw": "Value 3 (+)", "roll": "Value 2 (+)"}
        labels = {"pitch": "Nod up / down", "yaw": "Turn left / right", "roll": "Tilt side to side"}
        for r, key in enumerate(("pitch", "yaw", "roll")):
            ttk.Label(grid, text=labels[key], style="Card.TLabel", width=18).grid(row=r, column=0, sticky="w", pady=2)
            v = tk.StringVar(value=settings.get("phone_map_" + key, defaults[key]))
            ttk.Combobox(grid, textvariable=v, state="readonly", values=self.CHOICES, width=14).grid(row=r, column=1, padx=6)
            v.trace_add("write", lambda *_: self.apply_mapping())
            self.map_vars[key] = v
        ttk.Label(grid, text="Not sure which is which? Start listening, move your head one way at a time and "
                  "watch which 'Value' changes below. Flip the sign if it goes the wrong way.",
                  style="Muted.TLabel", wraplength=560, justify="left").grid(row=3, column=0, columnspan=3, sticky="w", pady=(6, 0))

        live = ft.App.card(face_app, parent, "Live")
        live.pack(fill="x", padx=pad, pady=pad)
        self.status = ttk.Label(live, text="Not listening", style="Card.TLabel", font=("Segoe UI", 11, "bold"))
        self.status.pack(anchor="w")
        self.raw_label = ttk.Label(live, text="Incoming  -", style="Muted.TLabel")
        self.raw_label.pack(anchor="w", pady=(4, 0))
        self.head_label = ttk.Label(live, text="Head  -", style="Muted.TLabel")
        self.head_label.pack(anchor="w")
        self.seen_label = ttk.Label(live, text="", style="Muted.TLabel", wraplength=560, justify="left")
        self.seen_label.pack(anchor="w", pady=(4, 0))
        self.apply_mapping()

    def apply_mapping(self):
        if not self.imu:
            return
        for key, var in self.map_vars.items():
            text = var.get()
            idx = int(text.split()[1]) - 1
            self.imu.mapping[key] = (idx, 1 if "(+)" in text else -1)

    def apply_use(self):
        pi.ACTIVE[0] = self.imu if (self.imu and self.use_var.get()) else None

    def recenter(self):
        if self.imu:
            self.imu.recenter()

    def toggle(self):
        if self.imu:
            self.stop()
            return
        try:
            port = int(self.port_var.get())
        except ValueError:
            self.status.configure(text="Port must be a number")
            return
        self.imu = pi.PhoneIMU(port, self.addr_var.get().strip(), bool(self.rad_var.get()))
        self.apply_mapping()
        self.imu.start()
        self.apply_use()
        self.go.configure(text="Stop listening", style="Stop.TButton")

    def stop(self):
        if self.imu:
            self.imu.stop()
        self.imu = None
        pi.ACTIVE[0] = None
        self.go.configure(text="Start listening", style="Accent.TButton")
        self.status.configure(text="Not listening")

    def save(self):
        self.settings["phone_port"] = self.port_var.get()
        self.settings["phone_address"] = self.addr_var.get()
        self.settings["phone_radians"] = int(self.rad_var.get())
        self.settings["phone_use"] = int(self.use_var.get())
        for key, var in self.map_vars.items():
            self.settings["phone_map_" + key] = var.get()

    def poll(self):
        if not self.imu:
            return
        snap = self.imu.snapshot()
        if snap["error"]:
            self.status.configure(text=snap["error"])
            return
        if snap["raw"] is None:
            self.status.configure(text="Listening... nothing received yet")
            seen = snap["seen"]
            self.seen_label.configure(text=("Addresses seen: " + ", ".join(seen)) if seen else
                                      "Check the phone's target IP and port, and the Windows firewall.")
            return
        fresh = snap["age"] is not None and snap["age"] < 0.5
        self.status.configure(text="Receiving" if fresh else "Signal lost")
        r = snap["raw"]
        self.raw_label.configure(text="Incoming (degrees)  Value 1 %+.0f   Value 2 %+.0f   Value 3 %+.0f" % tuple(r))
        h = self.imu.head()
        if h:
            self.head_label.configure(text="Head  nod %+.0f   turn %+.0f   tilt %+.0f" % h)
        self.seen_label.configure(text="Addresses seen: " + ", ".join(snap["seen"]))


SKEL_BONES = [(3, 2), (2, 4), (2, 8), (2, 1), (1, 0), (0, 12), (0, 16),
              (4, 5), (5, 6), (6, 7), (8, 9), (9, 10), (10, 11),
              (12, 13), (13, 14), (14, 15), (16, 17), (17, 18), (18, 19)]


class SkeletonTab:
    """Draws the Kinect skeleton that Garry's Mod writes out (needs gmmt_skeleton_export.lua)."""

    W, H = 360, 440

    def __init__(self, root, parent, face_app):
        self.root, self.face_app = root, face_app
        self.active = False
        self.last_req = 0.0
        self.side = tk.IntVar(value=0)
        pad = 12
        card = ft.App.card(face_app, parent, "Kinect skeleton (live from Garry's Mod)")
        card.pack(padx=pad, pady=pad)
        self.canvas = tk.Canvas(card, width=self.W, height=self.H, bg="#0d0e11", highlightthickness=0)
        self.canvas.pack()
        row = ttk.Frame(card, style="Card.TFrame")
        row.pack(fill="x", pady=(8, 0))
        self.go = ttk.Button(row, text="Show skeleton", style="Accent.TButton", command=self.toggle)
        self.go.pack(side="left")
        ttk.Checkbutton(row, text="Side view", variable=self.side).pack(side="left", padx=10)
        self.status = ttk.Label(card, text="Off", style="Muted.TLabel", wraplength=340, justify="left")
        self.status.pack(anchor="w", pady=(6, 0))
        ttk.Label(card, text="Needs gmmt_skeleton_export.lua in lua/autorun/client and a Kinect controller "
                  "running in Garry's Mod.", style="Muted.TLabel", wraplength=340, justify="left").pack(anchor="w")

    def _data_dir(self):
        return self.face_app.dir_var.get().strip()

    def toggle(self):
        if self.active:
            self.stop()
            return
        if not os.path.isdir(self._data_dir()):
            self.status.configure(text="Pick your garrysmod\\data folder on the Face tab first.")
            return
        self.active = True
        self.go.configure(text="Hide skeleton", style="Stop.TButton")
        self.touch(force=True)

    def stop(self):
        self.active = False
        self.go.configure(text="Show skeleton", style="Accent.TButton")
        self.canvas.delete("all")
        self.status.configure(text="Off")
        try:
            os.remove(os.path.join(self._data_dir(), "gmmt_skeleton_request.txt"))
        except OSError:
            pass

    def touch(self, force=False):
        now = time.time()
        if force or now - self.last_req >= 1.0:
            self.last_req = now
            try:
                with open(os.path.join(self._data_dir(), "gmmt_skeleton_request.txt"), "w") as f:
                    f.write(str(int(now)))
            except OSError:
                pass

    def poll(self):
        if not self.active:
            return
        self.touch()
        path = os.path.join(self._data_dir(), "gmmt_kinect_skeleton.txt")
        try:
            if time.time() - os.path.getmtime(path) > 3:
                raise OSError
            with open(path) as f:
                data = json.load(f)
        except (OSError, ValueError):
            self.canvas.delete("all")
            self.status.configure(text="Waiting for Garry's Mod... (is the export file installed and a map loaded?)")
            return
        joints = data.get("joints") or []
        if len(joints) < 20:
            return
        self.status.configure(text="Tracking a body" if data.get("tracking") else "Sensor sees nobody")
        self.draw(joints, bool(data.get("tracking")))

    def draw(self, J, tracking):
        c = self.canvas
        c.delete("all")
        # The sensor's axes are not guaranteed, so find them from the body itself:
        # up = the axis head and hip differ along most, sideways = the one the shoulders differ along most.
        d = [abs(J[3][i] - J[0][i]) for i in range(3)]
        up = d.index(max(d))
        rest = [i for i in range(3) if i != up]
        sh = [abs(J[4][i] - J[8][i]) for i in rest]
        across = rest[sh.index(max(sh))]
        depth = [i for i in rest if i != across][0]
        horiz = depth if self.side.get() else across
        us = 1 if J[3][up] >= J[0][up] else -1
        hs = 1 if J[4][horiz] >= J[8][horiz] else -1  # left shoulder on the right of the screen
        pts = [(hs * j[horiz], us * j[up]) for j in J]
        xs = [p[0] for p in pts]
        ys = [p[1] for p in pts]
        span = max(max(xs) - min(xs), max(ys) - min(ys), 0.5)
        s = (self.H - 60) / span
        cx = (max(xs) + min(xs)) / 2
        cy = (max(ys) + min(ys)) / 2

        def sc(p):
            return (self.W / 2 + (p[0] - cx) * s, self.H / 2 - (p[1] - cy) * s)
        col = "#5ee08a" if tracking else "#777777"
        for a, b in SKEL_BONES:
            x1, y1 = sc(pts[a])
            x2, y2 = sc(pts[b])
            c.create_line(x1, y1, x2, y2, fill=col, width=3)
        for i, p in enumerate(pts):
            x, y = sc(p)
            r = 7 if i == 3 else 4
            c.create_oval(x - r, y - r, x + r, y + r, fill="#ffffff" if i == 3 else col, outline="")


def main():
    settings = ft.load_settings()
    if not os.path.isdir(settings["data_dir"]):
        guess = ft.guess_data_dir()
        if guess:
            settings["data_dir"] = guess

    root = tk.Tk()
    root.title("GMMT - Garry's Mod Motion Tracker")
    root.configure(bg=ft.BG)
    root.resizable(False, False)

    nb = ttk.Notebook(root)
    nb.pack(fill="both", expand=True)
    face_tab = ttk.Frame(nb)
    finger_tab = ttk.Frame(nb)
    phone_tab = ttk.Frame(nb)
    skel_tab = ttk.Frame(nb)
    nb.add(face_tab, text="  Face  ")
    nb.add(finger_tab, text="  Fingers  ")
    nb.add(phone_tab, text="  Phone  ")
    nb.add(skel_tab, text="  Skeleton  ")

    face_app = ft.App(root, settings, False, parent=face_tab, standalone=False)
    # the notebook needs matching colours (style is created by App)
    style = ttk.Style(root)
    style.configure("TNotebook", background=ft.BG, borderwidth=0)
    style.configure("TNotebook.Tab", background=ft.EDGE, foreground=ft.TEXT, padding=(14, 6))
    style.map("TNotebook.Tab", background=[("selected", ft.PANEL)])

    fingers = FingerTab(root, finger_tab, face_app, settings)
    phone = PhoneTab(root, phone_tab, face_app, settings)
    skeleton = SkeletonTab(root, skel_tab, face_app)

    def poll_fingers():
        try:
            fingers.poll()
            phone.poll()
            skeleton.poll()
        finally:
            root.after(50, poll_fingers)
    root.after(50, poll_fingers)

    def on_close():
        face_app.persist()
        face_app.stop_tracker()
        fingers.stop()
        phone.save()
        phone.stop()
        skeleton.stop()
        ft.save_settings(settings)
        root.destroy()
    root.protocol("WM_DELETE_WINDOW", on_close)
    root.mainloop()


if __name__ == "__main__":
    main()
