"""
Finger tracker (MediaPipe Hands) for the SMH tools.

Reads a webcam, measures how much each finger is curled and writes it ~30
times a second to garrysmod/data/smh_finger_tracking.txt for the GMod addon.

Install once:   py -m pip install mediapipe opencv-python numpy
Run:            py finger_tracker.py --data-dir "D:\\...\\garrysmod\\data" --camera 0
Quit:           press Q in the preview window (or Ctrl+C in the console).

The data folder and camera are remembered in finger_tracker_settings.json, and
the data folder is also read from face_tracker_settings.json if that exists.
"""
import argparse
import json
import math
import os
import sys
import threading
import time
import urllib.request

try:
    import cv2
    import mediapipe as mp
    import numpy as np
    from mediapipe.tasks import python as mp_python
    from mediapipe.tasks.python import vision
except ImportError as e:
    print("Missing package:", e)
    print("Run:  py -m pip install mediapipe opencv-python numpy")
    sys.exit(1)

HERE = os.path.dirname(os.path.abspath(__file__))
SETTINGS_PATH = os.path.join(HERE, "finger_tracker_settings.json")
FACE_SETTINGS_PATH = os.path.join(HERE, "face_tracker_settings.json")
MODEL_PATH = os.path.join(HERE, "hand_landmarker.task")
MODEL_URL = ("https://storage.googleapis.com/mediapipe-models/hand_landmarker/"
             "hand_landmarker/float16/1/hand_landmarker.task")
OUTPUT_NAME = "smh_finger_tracking.txt"

# Landmark ids: wrist 0; thumb 1-4; index 5-8; middle 9-12; ring 13-16; pinky 17-20
FINGERS = {
    "thumb":  (0, 1, 2, 3, 4),
    "index":  (0, 5, 6, 7, 8),
    "middle": (0, 9, 10, 11, 12),
    "ring":   (0, 13, 14, 15, 16),
    "pinky":  (0, 17, 18, 19, 20),
}


def load_json(path):
    try:
        with open(path) as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def angle_deviation(a, b, c):
    """How far the chain a-b-c is bent at b, in degrees (0 = perfectly straight)."""
    v1 = a - b
    v2 = c - b
    n1 = np.linalg.norm(v1)
    n2 = np.linalg.norm(v2)
    if n1 < 1e-6 or n2 < 1e-6:
        return 0.0
    cosang = float(np.dot(v1, v2) / (n1 * n2))
    cosang = max(-1.0, min(1.0, cosang))
    return 180.0 - math.degrees(math.acos(cosang))


def finger_curls(points):
    """points: 21x3 array (hand world landmarks). Returns {finger: [j1, j2, j3]} degrees."""
    out = {}
    for name, (w, p1, p2, p3, p4) in FINGERS.items():
        j1 = angle_deviation(points[w], points[p1], points[p2])
        j2 = angle_deviation(points[p1], points[p2], points[p3])
        j3 = angle_deviation(points[p2], points[p3], points[p4])
        out[name] = [round(max(0.0, min(110.0, j)), 1) for j in (j1, j2, j3)]
    return out


def hand_frame(points, real_side):
    """Orthonormal hand axes (forward f, side s, palm normal n) from the palm landmarks, or None."""
    wrist, idx, mid, pky = points[0], points[5], points[9], points[17]
    f = mid - wrist
    nf = np.linalg.norm(f)
    if nf < 1e-6:
        return None
    f = f / nf
    n = np.cross(idx - wrist, pky - wrist)
    if real_side == "left":
        n = -n
    nn = np.linalg.norm(n)
    if nn < 1e-6:
        return None
    n = n / nn
    s_ = np.cross(n, f)
    s_ = s_ / max(np.linalg.norm(s_), 1e-6)
    n = np.cross(f, s_)
    return f, s_, n


def _wrap(a):
    return (a + 180.0) % 360.0 - 180.0


def finger_extras(points, real_side):
    """EXPERIMENTAL full-rotation values, in the same hand frame for every finger.
    Returns {finger: (flex1, spread, lift)} in degrees:
      flex1  - bend of the knuckle joint measured in the palm's own plane (not fooled by spreading)
      spread - side-to-side lean of the finger, 0 = fingers together, + toward the thumb side
      lift   - thumb only: how far the thumb is raised off the palm"""
    fr = hand_frame(points, real_side)
    if fr is None:
        return None
    f, s_, n = fr
    side = 1.0 if float((points[5] - points[17]) @ s_) >= 0 else -1.0   # +1 = toward the thumb side
    out = {}
    for name, (w, p1, p2, p3, p4) in FINGERS.items():
        if name == "thumb":
            d = points[p2] - points[p1]
            df, ds, dn = float(d @ f), float(d @ s_), float(d @ n)
            spread = math.degrees(math.atan2(ds * side, df))
            lift = math.degrees(math.atan2(abs(dn), math.hypot(df, ds)))
            out[name] = (0.0, spread, lift)
            continue
        m = points[p1] - points[w]            # the finger's palm bone (for the knuckle bend)
        d = points[p2] - points[p1]           # the first finger bone
        mf, mn = float(m @ f), float(m @ n)
        df, ds, dn = float(d @ f), float(d @ s_), float(d @ n)
        flex = abs(_wrap(math.degrees(math.atan2(dn, df)) - math.degrees(math.atan2(mn, mf))))
        # side-to-side angle against the hand's forward axis: fingers held together read 0,
        # positive = leaning toward the thumb side, for both hands
        spread = math.degrees(math.atan2(ds * side, math.hypot(df, dn)))
        out[name] = (flex, spread, 0.0)
    return out


# ---- Smoothing + hand rotation ----------------------------------------------

class OneEuro:
    """One-Euro filter: steady when still, quick when moving fast."""
    def __init__(self, min_cutoff=1.5, beta=0.02, dcutoff=1.0):
        self.min_cutoff = min_cutoff
        self.beta = beta
        self.dcutoff = dcutoff
        self.x = None
        self.dx = 0.0
        self.t = None

    @staticmethod
    def _alpha(cutoff, dt):
        tau = 1.0 / (2.0 * math.pi * cutoff)
        return 1.0 / (1.0 + tau / dt)

    def __call__(self, value, t):
        if self.x is None or self.t is None:
            self.x, self.t = value, t
            return value
        dt = max(t - self.t, 1e-3)
        self.t = t
        dx = (value - self.x) / dt
        self.dx += self._alpha(self.dcutoff, dt) * (dx - self.dx)
        cutoff = self.min_cutoff + self.beta * abs(self.dx)
        self.x += self._alpha(cutoff, dt) * (value - self.x)
        return self.x


def hand_rotation(points, real_side):
    """Palm orientation as (roll, pitch, yaw) degrees relative to a neutral pose
    (palm facing the camera, fingers pointing up).
    roll  = twist about the hand's forward axis
    pitch = wrist flex (up/down) about the side axis
    yaw   = side-to-side bend about the palm normal"""
    wrist, idx, mid, pky = points[0], points[5], points[9], points[17]
    f = mid - wrist
    nf = np.linalg.norm(f)
    if nf < 1e-6:
        return (0.0, 0.0, 0.0)
    f = f / nf
    n = np.cross(idx - wrist, pky - wrist)
    if real_side == "left":
        n = -n
    nn = np.linalg.norm(n)
    if nn < 1e-6:
        return (0.0, 0.0, 0.0)
    n = n / nn
    s = np.cross(n, f)
    s = s / max(np.linalg.norm(s), 1e-6)
    n = np.cross(f, s)
    # neutral: forward = up (-y), palm normal = toward camera (-z)
    nf_, nn_ = np.array([0.0, -1.0, 0.0]), np.array([0.0, 0.0, -1.0])
    ns_ = np.cross(nn_, nf_)
    N = np.column_stack([nf_, ns_, nn_])
    R = np.column_stack([f, s, n])
    Rr = N.T @ R
    yaw = math.degrees(math.atan2(Rr[1, 0], Rr[0, 0]))
    pitch = math.degrees(-math.asin(max(-1.0, min(1.0, Rr[2, 0]))))
    roll = math.degrees(math.atan2(Rr[2, 1], Rr[2, 2]))
    return (roll, pitch, yaw)


class HandSmoother:
    """Per-hand filtering, joint coupling and a short hold when tracking drops."""
    HOLD_SECONDS = 0.3
    RESET_SECONDS = 0.8

    def __init__(self, smoothing=0.5):
        self.filters = {}
        self.last = {}        # side -> (time, data)
        self.set_smoothing(smoothing)

    def set_smoothing(self, smoothing):
        smoothing = max(0.0, min(1.0, smoothing))
        self.min_cutoff = 4.0 - 3.6 * smoothing   # 4.0 (light) .. 0.4 (heavy)
        for f in self.filters.values():
            f.min_cutoff = self.min_cutoff

    def _f(self, key):
        f = self.filters.get(key)
        if f is None:
            f = OneEuro(self.min_cutoff, 0.02)
            self.filters[key] = f
        return f

    def process(self, side, points, t, full=False):
        curls = finger_curls(points)
        extras = finger_extras(points, side) if full else None
        out = {}
        for name, (j1, j2, j3) in curls.items():
            if name != "thumb":
                # the last joint follows the middle one; blend to cancel noise
                j3 = 0.5 * j3 + 0.5 * (0.67 * j2)
            vals = [j1, j2, j3]
            if extras:
                flex, spread, lift = extras[name]
                if name != "thumb":
                    vals[0] = max(0.0, min(110.0, flex))
                vals += [max(-60.0, min(60.0, spread)), max(0.0, min(90.0, lift))]
            out[name] = [round(self._f((side, name, i))(v, t), 1) for i, v in enumerate(vals)]
        roll, pitch, yaw = hand_rotation(points, side)
        out["rot"] = {
            "roll": round(self._f((side, "rot", "roll"))(roll, t), 1),
            "pitch": round(self._f((side, "rot", "pitch"))(pitch, t), 1),
            "yaw": round(self._f((side, "rot", "yaw"))(yaw, t), 1),
        }
        self.last[side] = (t, out)
        return out

    def held(self, side, t):
        """Last value for a hand that just vanished (None once it has been gone a while)."""
        item = self.last.get(side)
        if not item:
            return None
        age = t - item[0]
        if age > self.RESET_SECONDS:
            for k in [k for k in self.filters if k[0] == side]:
                del self.filters[k]
            self.last.pop(side, None)
            return None
        return item[1] if age <= self.HOLD_SECONDS else None


def write_output(path, payload):
    tmp = path + ".tmp"
    try:
        with open(tmp, "w") as f:
            json.dump(payload, f, separators=(",", ":"))
        os.replace(tmp, path)
    except OSError:
        pass  # GMod is reading it right now; skip this frame


try:
    import camera_hub
except Exception:
    camera_hub = None


def open_camera(index):
    if camera_hub is not None:
        return camera_hub.open_camera(index)
    if os.name == "nt":
        return cv2.VideoCapture(index, cv2.CAP_DSHOW)
    return cv2.VideoCapture(index)


class FingerTracker(threading.Thread):
    """Camera + MediaPipe Hands in a thread. The GMMT window reads snapshot()."""

    def __init__(self, camera, out_path, preview_width=320):
        super().__init__(daemon=True)
        self.camera = camera
        self.out_path = out_path
        self.preview_width = preview_width
        self.preview_on = [True]
        self.smoothing = [0.5]       # shared with the window (0 light .. 1 heavy)
        self.full = [False]          # experimental: also measure spread / thumb lift
        self.stop_event = threading.Event()
        self.lock = threading.Lock()
        self._state = {"status": "starting", "message": "Starting...", "hands": {},
                       "fps": 0.0, "png": None, "png_id": 0}

    def _set(self, **kw):
        with self.lock:
            self._state.update(kw)

    def snapshot(self):
        with self.lock:
            return dict(self._state)

    def stop(self):
        self.stop_event.set()

    def run(self):
        import base64
        cap = None
        landmarker = None
        try:
            if not os.path.exists(MODEL_PATH):
                self._set(status="downloading", message="Downloading the hand model (one time only)...")
                urllib.request.urlretrieve(MODEL_URL, MODEL_PATH + ".part")
                os.replace(MODEL_PATH + ".part", MODEL_PATH)
            options = vision.HandLandmarkerOptions(
                base_options=mp_python.BaseOptions(model_asset_path=MODEL_PATH),
                running_mode=vision.RunningMode.VIDEO, num_hands=2)
            landmarker = vision.HandLandmarker.create_from_options(options)
            cap = open_camera(self.camera)
            if not cap.isOpened():
                self._set(status="error", message="Could not open camera %d (is another tracker using it?)." % self.camera)
                return
            last_ts = -1
            frames = 0
            fps_time = time.time()
            n = 0
            smoother = HandSmoother(self.smoothing[0])
            self._set(status="tracking", message="Tracking")
            while not self.stop_event.is_set():
                ok, frame = cap.read()
                if not ok:
                    self._set(status="error", message="Lost the camera feed.")
                    break
                rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb)
                ts = int(time.monotonic() * 1000)
                if ts <= last_ts:
                    ts = last_ts + 1
                last_ts = ts
                result = landmarker.detect_for_video(image, ts)
                hands = {}
                tnow = time.time()
                smoother.set_smoothing(self.smoothing[0])
                for i, world in enumerate(result.hand_world_landmarks or []):
                    label = result.handedness[i][0].category_name
                    real = "right" if label == "Left" else "left"
                    pts = np.array([[p.x, p.y, p.z] for p in world], dtype=float)
                    hands[real] = smoother.process(real, pts, tnow, self.full[0])
                out_hands = dict(hands)
                for side in ("left", "right"):
                    if side not in out_hands:
                        held = smoother.held(side, tnow)
                        if held:
                            out_hands[side] = held
                write_output(self.out_path, {"t": int(time.time()), "hands": out_hands})
                frames += 1
                n += 1
                update = {"status": "tracking" if hands else "nohands",
                          "message": "Tracking" if hands else "No hands visible", "hands": hands}
                now = time.time()
                if now - fps_time >= 1.0:
                    update["fps"] = frames / (now - fps_time)
                    frames = 0
                    fps_time = now
                if self.preview_on[0] and n % 2 == 0:
                    shown = cv2.flip(frame, 1)
                    h, w = shown.shape[:2]
                    small = cv2.resize(shown, (self.preview_width, int(h * self.preview_width / w)))
                    okp, buf = cv2.imencode(".png", small)
                    if okp:
                        update["png"] = base64.b64encode(buf.tobytes())
                        update["png_id"] = self._state["png_id"] + 1
                self._set(**update)
        except Exception as exc:
            self._set(status="error", message="Error: %s" % exc)
        finally:
            write_output(self.out_path, {"t": 0, "hands": {}})
            if cap is not None:
                cap.release()
            if landmarker is not None:
                landmarker.close()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", default=None)
    parser.add_argument("--camera", type=int, default=None)
    parser.add_argument("--no-preview", action="store_true")
    args = parser.parse_args()

    settings = load_json(SETTINGS_PATH)
    face = load_json(FACE_SETTINGS_PATH)
    data_dir = args.data_dir or settings.get("data_dir") or face.get("data_dir")
    camera = args.camera if args.camera is not None else settings.get("camera", 0)
    if not data_dir or not os.path.isdir(data_dir):
        print("Give the garrysmod data folder:  --data-dir \"...\\garrysmod\\data\"")
        sys.exit(1)
    try:
        with open(SETTINGS_PATH, "w") as f:
            json.dump({"data_dir": data_dir, "camera": camera}, f, indent=2)
    except OSError:
        pass
    out_path = os.path.join(data_dir, OUTPUT_NAME)

    if not os.path.exists(MODEL_PATH):
        print("Downloading the hand model (one time only)...")
        urllib.request.urlretrieve(MODEL_URL, MODEL_PATH + ".part")
        os.replace(MODEL_PATH + ".part", MODEL_PATH)

    options = vision.HandLandmarkerOptions(
        base_options=mp_python.BaseOptions(model_asset_path=MODEL_PATH),
        running_mode=vision.RunningMode.VIDEO,
        num_hands=2,
    )
    landmarker = vision.HandLandmarker.create_from_options(options)

    cap = open_camera(camera)
    if not cap.isOpened():
        print("Could not open camera %d. Try --camera 1." % camera)
        sys.exit(1)

    print("Tracking fingers. Writing to", out_path)
    smoother = HandSmoother(0.5)
    last_ts = -1
    try:
        while True:
            ok, frame = cap.read()
            if not ok:
                print("Lost the camera feed.")
                break
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb)
            ts = int(time.monotonic() * 1000)
            if ts <= last_ts:
                ts = last_ts + 1
            last_ts = ts
            result = landmarker.detect_for_video(image, ts)

            hands = {}
            tnow = time.time()
            for i, world in enumerate(result.hand_world_landmarks or []):
                label = result.handedness[i][0].category_name  # "Left"/"Right"
                # MediaPipe assumes a mirrored image; our frame is not mirrored,
                # so the label is the opposite of the person's real hand.
                real = "right" if label == "Left" else "left"
                pts = np.array([[p.x, p.y, p.z] for p in world], dtype=float)
                hands[real] = smoother.process(real, pts, tnow)
            out_hands = dict(hands)
            for side in ("left", "right"):
                if side not in out_hands:
                    held = smoother.held(side, tnow)
                    if held:
                        out_hands[side] = held

            write_output(out_path, {"t": int(time.time()), "hands": out_hands})

            if not args.no_preview:
                shown = cv2.flip(frame, 1)
                txt = "hands: " + (", ".join(sorted(hands)) if hands else "none")
                cv2.putText(shown, txt, (10, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
                cv2.imshow("Finger tracker (Q to quit)", shown)
                if cv2.waitKey(1) & 0xFF in (ord("q"), ord("Q")):
                    break
    except KeyboardInterrupt:
        pass
    finally:
        cap.release()
        cv2.destroyAllWindows()
        write_output(out_path, {"t": 0, "hands": {}})


if __name__ == "__main__":
    main()
