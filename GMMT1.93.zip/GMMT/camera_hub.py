"""Shared camera for GMMT.

One thread reads each physical camera once; the Face and Finger trackers each get
a Reader that behaves like cv2.VideoCapture (isOpened / read / release), so both
can run on the same camera at the same time.
"""
import sys
import threading
import time

import cv2

_lock = threading.Lock()
_cams = {}


class _Camera(threading.Thread):
    def __init__(self, index):
        super().__init__(daemon=True)
        self.index = index
        self.cond = threading.Condition()
        self.frame = None
        self.frame_id = 0
        self.refs = 0
        self.opened = False
        self.failed = False
        self.stop_flag = False
        self.ready = threading.Event()

    def run(self):
        if sys.platform.startswith("win"):
            cap = cv2.VideoCapture(self.index, cv2.CAP_DSHOW)
        else:
            cap = cv2.VideoCapture(self.index)
        self.opened = bool(cap.isOpened())
        self.ready.set()
        try:
            while self.opened and not self.stop_flag:
                ok, frame = cap.read()
                if not ok:
                    self.failed = True
                    break
                with self.cond:
                    self.frame = frame
                    self.frame_id += 1
                    self.cond.notify_all()
        finally:
            cap.release()
            with self.cond:
                self.failed = True
                self.cond.notify_all()


class Reader:
    """Drop-in for the bits of cv2.VideoCapture the trackers use."""

    def __init__(self, cam):
        self._cam = cam
        self._seen = 0
        self._released = False

    def isOpened(self):
        return self._cam.opened

    def read(self, timeout=2.0):
        cam = self._cam
        end = time.time() + timeout
        with cam.cond:
            while cam.frame_id == self._seen and not cam.failed:
                left = end - time.time()
                if left <= 0:
                    return False, None
                cam.cond.wait(left)
            if cam.frame is None or cam.frame_id == self._seen:
                return False, None
            self._seen = cam.frame_id
            return True, cam.frame  # trackers never modify the frame in place

    def release(self):
        if self._released:
            return
        self._released = True
        with _lock:
            cam = self._cam
            cam.refs -= 1
            if cam.refs <= 0:
                cam.stop_flag = True
                if _cams.get(cam.index) is cam:
                    del _cams[cam.index]


def open_camera(index):
    with _lock:
        cam = _cams.get(index)
        if cam is None or cam.failed or cam.stop_flag:
            cam = _Camera(index)
            _cams[index] = cam
            cam.start()
        cam.refs += 1
    cam.ready.wait(10)
    return Reader(cam)
