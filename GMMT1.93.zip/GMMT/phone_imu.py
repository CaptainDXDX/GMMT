"""Phone gyroscope -> head rotation for GMMT.

Listens for OSC over UDP (for example from the iOS app GyrOSC) and turns three
angles into head pitch / yaw / roll in degrees. A phone strapped to your head
tracks rotation far better than a camera that is also on your head.

Because apps differ in which angle is which, every head axis can be mapped to any
of the three incoming values (with a sign), and 'Recenter' zeroes the pose.
Nothing here is verified against a real phone yet: use the live readout on the
Phone tab to pick the mapping.
"""
import socket
import struct
import threading
import time


def parse_osc(data):
    """Return a list of (address, [args]) from one UDP packet (messages and bundles)."""
    out = []
    try:
        if data.startswith(b"#bundle"):
            pos = 16
            while pos + 4 <= len(data):
                size = struct.unpack(">i", data[pos:pos + 4])[0]
                pos += 4
                out.extend(parse_osc(data[pos:pos + size]))
                pos += size
            return out
        end = data.index(b"\0")
        address = data[:end].decode("ascii", "replace")
        pos = (end + 4) & ~3
        tend = data.index(b"\0", pos)
        tags = data[pos:tend].decode("ascii", "replace")
        pos = (tend + 4) & ~3
        args = []
        for t in tags.lstrip(","):
            if t == "f":
                args.append(struct.unpack(">f", data[pos:pos + 4])[0]); pos += 4
            elif t == "d":
                args.append(struct.unpack(">d", data[pos:pos + 8])[0]); pos += 8
            elif t == "i":
                args.append(float(struct.unpack(">i", data[pos:pos + 4])[0])); pos += 4
            elif t == "s":
                e = data.index(b"\0", pos)
                args.append(data[pos:e].decode("utf-8", "replace"))
                pos = (e + 4) & ~3
            else:
                break
        out.append((address, args))
    except (ValueError, struct.error):
        pass
    return out


def wrap180(a):
    return (a + 180.0) % 360.0 - 180.0


class PhoneIMU(threading.Thread):
    def __init__(self, port=5550, address="/gyrosc/gyro", radians=True):
        super().__init__(daemon=True)
        self.port = port
        self.address = address
        self.radians = radians
        # head axis -> (index into the 3 incoming values, sign)
        self.mapping = {"pitch": (0, 1), "yaw": (2, 1), "roll": (1, 1)}
        self.stop_event = threading.Event()
        self.lock = threading.Lock()
        self.raw = None            # last 3 incoming values, in degrees
        self.zero = (0.0, 0.0, 0.0)
        self.last_time = 0.0
        self.seen = {}             # address -> arg count (to help pick the right one)
        self.error = None

    def recenter(self):
        with self.lock:
            if self.raw:
                self.zero = tuple(self.raw)

    def head(self):
        """(pitch, yaw, roll) in degrees, or None if no recent data."""
        with self.lock:
            if self.raw is None or time.time() - self.last_time > 0.5:
                return None
            vals = [wrap180(self.raw[i] - self.zero[i]) for i in range(3)]
            m = self.mapping
            return tuple(vals[m[k][0]] * m[k][1] for k in ("pitch", "yaw", "roll"))

    def snapshot(self):
        with self.lock:
            return {"raw": self.raw, "age": time.time() - self.last_time if self.last_time else None,
                    "seen": dict(self.seen), "error": self.error}

    def stop(self):
        self.stop_event.set()

    def run(self):
        sock = None
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.bind(("0.0.0.0", self.port))
            sock.settimeout(0.25)
        except OSError as exc:
            self.error = "Could not listen on port %d: %s" % (self.port, exc)
            return
        try:
            while not self.stop_event.is_set():
                try:
                    data, _ = sock.recvfrom(4096)
                except socket.timeout:
                    continue
                except OSError:
                    break
                for address, args in parse_osc(data):
                    nums = [a for a in args if isinstance(a, float)]
                    with self.lock:
                        self.seen[address] = len(nums)
                    if address == self.address and len(nums) >= 3:
                        v = nums[:3]
                        if self.radians:
                            v = [x * 57.29577951308232 for x in v]
                        with self.lock:
                            self.raw = v
                            self.last_time = time.time()
        finally:
            if sock is not None:
                sock.close()


# The Face tracker looks here. The Phone tab sets it while 'use phone for head' is on.
ACTIVE = [None]


def current_head():
    imu = ACTIVE[0]
    return imu.head() if imu is not None else None
