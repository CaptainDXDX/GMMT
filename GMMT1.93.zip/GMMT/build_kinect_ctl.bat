@echo off
setlocal
cd /d "%~dp0"
echo Building kinect_ctl.exe ...
set "KDLL=%KINECTSDK10_DIR%Assemblies\Microsoft.Kinect.dll"
if exist "%KDLL%" goto havedll
set "KDLL=C:\Program Files\Microsoft SDKs\Kinect\v1.8\Assemblies\Microsoft.Kinect.dll"
if exist "%KDLL%" goto havedll
echo Could not find Microsoft.Kinect.dll. Install the Kinect for Windows SDK 1.8 first.
goto done
:havedll
echo Using %KDLL%
set "CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if exist "%CSC%" goto havecsc
set "CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if exist "%CSC%" goto havecsc
echo Could not find csc.exe - the .NET Framework 4 compiler that ships with Windows.
goto done
:havecsc
if not exist "kinect_ctl.cs" (
  echo kinect_ctl.cs must be in the same folder as this file.
  goto done
)
copy /Y "%KDLL%" "Microsoft.Kinect.dll" >nul
"%CSC%" /nologo /target:exe /out:kinect_ctl.exe /reference:"%KDLL%" /reference:System.Drawing.dll kinect_ctl.cs
if errorlevel 1 goto failed
echo.
echo Built kinect_ctl.exe. Restart GMMT and use the Kinect tab.
goto done
:failed
echo.
echo Build failed. Copy the error text above and send it back.
:done
echo.
pause
