"""
GMMT - Garry's Mod Motion Tracker (hub)

One window with a tab per tracker:
  Face     - webcam face / eyes / head   (face_tracker.py)
  Fingers  - webcam finger curl          (finger_tracker.py)
More tabs (body tracking, timeline render) will be added here later.

Install once:  py -m pip install mediapipe opencv-python numpy
Run:           py gmmt.py
Keep gmmt.py, face_tracker.py and finger_tracker.py in the same folder.

Note: a camera can only be used by one tracker at a time. To run face and
fingers together, give each tab a different camera number (for example a
phone used as a webcam).
"""
import os
import sys
import tkinter as tk
from tkinter import filedialog, ttk

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
_missing = [n for n in ("face_tracker.py", "finger_tracker.py")
            if not os.path.exists(os.path.join(HERE, n))]
if _missing:
    print("GMMT needs these files in the same folder as this script:")
    for n in _missing:
        print("   missing:", n)
    print("Folder checked:", HERE)
    print("Download them next to this file (they must be named exactly like that).")
    input("Press Enter to close...")
    sys.exit(1)

import face_tracker as ft
import finger_tracker as fg


class FingerTab:
    def __init__(self, root, parent, face_app, settings):
        self.root = root
        self.parent = parent
        self.face_app = face_app      # to share the data folder box
        self.settings = settings
        self.tracker = None
        self.photo = None
        self.last_png_id = 0

        pad = 12
        top = ttk.Frame(parent, padding=(pad, pad, pad, 0))
        top.pack(fill="x")

        left = ttk.Frame(top)
        left.pack(side="left", anchor="n")
        card = ft.App.card(face_app, left, "")
        card.pack()
        self.preview = tk.Label(card, bg="#0d0e11", fg=ft.MUTED, width=ft.PREVIEW_WIDTH // 8,
                                height=15, text="Camera preview\n(press Start)", justify="center",
                                font=("Segoe UI", 10))
        self.preview.pack()

        right = ttk.Frame(top)
        right.pack(side="left", anchor="n", padx=(pad, 0), fill="y")
        cam_card = ft.App.card(face_app, right, "Camera")
        cam_card.pack(fill="x")
        self.cam_var = tk.StringVar(value="Camera %d" % settings.get("finger_camera", 0))
        self.cam_box = ttk.Combobox(cam_card, textvariable=self.cam_var, state="readonly",
                                    values=["Camera %d" % i for i in range(6)], width=14)
        self.cam_box.pack(anchor="w")
        self.preview_var = tk.IntVar(value=1)
        ttk.Checkbutton(cam_card, text="Show preview", variable=self.preview_var,
                        command=self.on_preview).pack(anchor="w", pady=(8, 0))
        self.full_var = tk.IntVar(value=int(settings.get("finger_full", 0)))
        ttk.Checkbutton(cam_card, text="Experimental: full rotation\n(finger spread + thumb lift)",
                        variable=self.full_var, command=self.on_full).pack(anchor="w", pady=(6, 0))

        st = ft.App.card(face_app, right, "Status")
        st.pack(fill="x", pady=(10, 0))
        self.status = ttk.Label(st, text="Stopped", style="Card.TLabel", font=("Segoe UI", 11, "bold"))
        self.status.pack(anchor="w")
        self.detail = ttk.Label(st, text="Uses the garrysmod data folder from the Face tab.",
                                style="Muted.TLabel", wraplength=230, justify="left")
        self.detail.pack(anchor="w", pady=(4, 0))
        sm = ft.App.card(face_app, right, "Smoothing")
        sm.pack(fill="x", pady=(10, 0))
        self.smooth_var = tk.DoubleVar(value=settings.get("finger_smoothing", 0.5))
        ttk.Scale(sm, from_=0.0, to=1.0, variable=self.smooth_var, length=200,
                  command=lambda _v: self.on_smooth()).pack(anchor="w")
        ttk.Label(sm, text="left = quick, right = smoother", style="Muted.TLabel").pack(anchor="w")
        self.go = ttk.Button(right, text="Start tracking", style="Accent.TButton", command=self.toggle)
        self.go.pack(fill="x", pady=(10, 0))

        meters = ft.App.card(face_app, parent, "Finger curl (degrees)")
        meters.pack(fill="x", padx=pad, pady=pad)
        self.rows = {}
        grid = ttk.Frame(meters, style="Card.TFrame")
        grid.pack(fill="x")
        for c, name in enumerate(fg.FINGERS):
            ttk.Label(grid, text=name.title(), style="Head.TLabel").grid(row=0, column=c + 1, padx=6)
        for r, side in enumerate(("left", "right")):
            ttk.Label(grid, text=side.title(), style="Card.TLabel").grid(row=r + 1, column=0, sticky="w")
            for c, name in enumerate(fg.FINGERS):
                lab = ttk.Label(grid, text="-", style="Muted.TLabel", width=6)
                lab.grid(row=r + 1, column=c + 1, padx=6, pady=2)
                self.rows[(side, name)] = lab
        ttk.Label(meters, text="In Garry's Mod: open 'Finger Tracking' from the SMH tools strip. "
                  "To record, tick 'Nonphysical Bones' on a timeline.",
                  style="Muted.TLabel", wraplength=520, justify="left").pack(anchor="w", pady=(8, 0))

    def on_smooth(self):
        self.settings["finger_smoothing"] = round(self.smooth_var.get(), 2)
        if self.tracker:
            self.tracker.smoothing[0] = self.smooth_var.get()

    def on_full(self):
        self.settings["finger_full"] = int(self.full_var.get())
        if self.tracker:
            self.tracker.full[0] = bool(self.full_var.get())

    def on_preview(self):
        if self.tracker:
            self.tracker.preview_on[0] = bool(self.preview_var.get())

    def set_status(self, text, detail=None):
        self.status.configure(text=text)
        if detail is not None:
            self.detail.configure(text=detail)

    def toggle(self):
        if self.tracker and self.tracker.is_alive():
            self.stop()
            return
        path = self.face_app.dir_var.get().strip()
        if not os.path.isdir(path):
            self.set_status("Stopped", "Pick your garrysmod\\data folder on the Face tab first.")
            return
        try:
            camera = int(self.cam_var.get().split()[-1])
        except ValueError:
            camera = 0
        self.settings["finger_camera"] = camera
        self.tracker = fg.FingerTracker(camera, os.path.join(path, fg.OUTPUT_NAME))
        self.tracker.preview_on[0] = bool(self.preview_var.get())
        self.tracker.smoothing[0] = self.smooth_var.get()
        self.tracker.full[0] = bool(self.full_var.get())
        self.last_png_id = 0
        self.tracker.start()
        self.go.configure(text="Stop tracking", style="Stop.TButton")
        self.cam_box.configure(state="disabled")

    def stop(self):
        if self.tracker:
            self.tracker.stop()
            self.tracker.join(timeout=3)
        self.tracker = None
        self.go.configure(text="Start tracking", style="Accent.TButton")
        self.cam_box.configure(state="readonly")
        self.preview.configure(image="", text="Camera preview\n(press Start)",
                               width=ft.PREVIEW_WIDTH // 8, height=15)
        for lab in self.rows.values():
            lab.configure(text="-")
        self.set_status("Stopped", "")

    def poll(self):
        if self.tracker:
            snap = self.tracker.snapshot()
            if snap["status"] == "error":
                self.set_status("Problem", snap["message"])
                if not self.tracker.is_alive():
                    self.stop()
                    self.set_status("Problem", snap["message"])
            elif snap["status"] == "tracking":
                self.set_status("Tracking", "Sending to Garry's Mod.")
            elif snap["status"] == "nohands":
                self.set_status("No hands visible", "Hold your hands up in view of the camera.")
            else:
                self.set_status("Starting", snap["message"])
            if snap["png"] is not None and snap["png_id"] != self.last_png_id:
                self.last_png_id = snap["png_id"]
                try:
                    self.photo = tk.PhotoImage(data=snap["png"])
                    self.preview.configure(image=self.photo, text="", width=0, height=0)
                except tk.TclError:
                    pass
            for (side, name), lab in self.rows.items():
                v = snap["hands"].get(side, {}).get(name)
                lab.configure(text=("%d" % max(v)) if v else "-")

import json
import time
import phone_imu as pi


class PhoneTab:
    """Phone gyroscope (OSC over UDP) -> head rotation for the Face tracker."""

    CHOICES = ["Value 1 (+)", "Value 1 (-)", "Value 2 (+)", "Value 2 (-)", "Value 3 (+)", "Value 3 (-)"]

    def __init__(self, root, parent, face_app, settings):
        self.root, self.settings, self.face_app = root, settings, face_app
        self.imu = None
        pad = 12
        card = ft.App.card(face_app, parent, "Phone gyroscope")
        card.pack(fill="x", padx=pad, pady=(pad, 0))
        ttk.Label(card, text="Strap the phone to your head, install an app that sends OSC over Wi-Fi "
                  "(for example GyrOSC), and point it at this computer's IP address and the port below. "
                  "Your PC and phone must be on the same network.",
                  style="Muted.TLabel", wraplength=560, justify="left").pack(anchor="w")
        row = ttk.Frame(card, style="Card.TFrame")
        row.pack(fill="x", pady=(8, 0))
        ttk.Label(row, text="Port", style="Card.TLabel").pack(side="left")
        self.port_var = tk.StringVar(value=str(settings.get("phone_port", 5550)))
        ttk.Entry(row, textvariable=self.port_var, width=7).pack(side="left", padx=(6, 14))
        ttk.Label(row, text="OSC address", style="Card.TLabel").pack(side="left")
        self.addr_var = tk.StringVar(value=settings.get("phone_address", "/gyrosc/gyro"))
        ttk.Entry(row, textvariable=self.addr_var, width=16).pack(side="left", padx=(6, 14))
        self.rad_var = tk.IntVar(value=int(settings.get("phone_radians", 1)))
        ttk.Checkbutton(row, text="Angles are radians", variable=self.rad_var).pack(side="left")
        row2 = ttk.Frame(card, style="Card.TFrame")
        row2.pack(fill="x", pady=(8, 0))
        self.go = ttk.Button(row2, text="Start listening", style="Accent.TButton", command=self.toggle)
        self.go.pack(side="left")
        ttk.Button(row2, text="Recenter (look straight ahead)", command=self.recenter).pack(side="left", padx=8)
        self.use_var = tk.IntVar(value=int(settings.get("phone_use", 1)))
        ttk.Checkbutton(row2, text="Use phone for head rotation", variable=self.use_var,
                        command=self.apply_use).pack(side="left", padx=8)

        mp = ft.App.card(face_app, parent, "Which phone angle drives which head movement")
        mp.pack(fill="x", padx=pad, pady=(pad, 0))
        self.map_vars = {}
        grid = ttk.Frame(mp, style="Card.TFrame")   # the card already uses pack, so grid goes in its own frame
        grid.pack(fill="x")
        defaults = {"pitch": "Value 1 (+)", "yaw": "Value 3 (+)", "roll": "Value 2 (+)"}
        labels = {"pitch": "Nod up / down", "yaw": "Turn left / right", "roll": "Tilt side to side"}
        for r, key in enumerate(("pitch", "yaw", "roll")):
            ttk.Label(grid, text=labels[key], style="Card.TLabel", width=18).grid(row=r, column=0, sticky="w", pady=2)
            v = tk.StringVar(value=settings.get("phone_map_" + key, defaults[key]))
            ttk.Combobox(grid, textvariable=v, state="readonly", values=self.CHOICES, width=14).grid(row=r, column=1, padx=6)
            v.trace_add("write", lambda *_: self.apply_mapping())
            self.map_vars[key] = v
        ttk.Label(grid, text="Not sure which is which? Start listening, move your head one way at a time and "
                  "watch which 'Value' changes below. Flip the sign if it goes the wrong way.",
                  style="Muted.TLabel", wraplength=560, justify="left").grid(row=3, column=0, columnspan=3, sticky="w", pady=(6, 0))

        live = ft.App.card(face_app, parent, "Live")
        live.pack(fill="x", padx=pad, pady=pad)
        self.status = ttk.Label(live, text="Not listening", style="Card.TLabel", font=("Segoe UI", 11, "bold"))
        self.status.pack(anchor="w")
        self.raw_label = ttk.Label(live, text="Incoming  -", style="Muted.TLabel")
        self.raw_label.pack(anchor="w", pady=(4, 0))
        self.head_label = ttk.Label(live, text="Head  -", style="Muted.TLabel")
        self.head_label.pack(anchor="w")
        self.seen_label = ttk.Label(live, text="", style="Muted.TLabel", wraplength=560, justify="left")
        self.seen_label.pack(anchor="w", pady=(4, 0))
        self.apply_mapping()

    def apply_mapping(self):
        if not self.imu:
            return
        for key, var in self.map_vars.items():
            text = var.get()
            idx = int(text.split()[1]) - 1
            self.imu.mapping[key] = (idx, 1 if "(+)" in text else -1)

    def apply_use(self):
        pi.ACTIVE[0] = self.imu if (self.imu and self.use_var.get()) else None

    def recenter(self):
        if self.imu:
            self.imu.recenter()

    def toggle(self):
        if self.imu:
            self.stop()
            return
        try:
            port = int(self.port_var.get())
        except ValueError:
            self.status.configure(text="Port must be a number")
            return
        self.imu = pi.PhoneIMU(port, self.addr_var.get().strip(), bool(self.rad_var.get()))
        self.apply_mapping()
        self.imu.start()
        self.apply_use()
        self.go.configure(text="Stop listening", style="Stop.TButton")

    def stop(self):
        if self.imu:
            self.imu.stop()
        self.imu = None
        pi.ACTIVE[0] = None
        self.go.configure(text="Start listening", style="Accent.TButton")
        self.status.configure(text="Not listening")

    def save(self):
        self.settings["phone_port"] = self.port_var.get()
        self.settings["phone_address"] = self.addr_var.get()
        self.settings["phone_radians"] = int(self.rad_var.get())
        self.settings["phone_use"] = int(self.use_var.get())
        for key, var in self.map_vars.items():
            self.settings["phone_map_" + key] = var.get()

    def poll(self):
        if not self.imu:
            return
        snap = self.imu.snapshot()
        if snap["error"]:
            self.status.configure(text=snap["error"])
            return
        if snap["raw"] is None:
            self.status.configure(text="Listening... nothing received yet")
            seen = snap["seen"]
            self.seen_label.configure(text=("Addresses seen: " + ", ".join(seen)) if seen else
                                      "Check the phone's target IP and port, and the Windows firewall.")
            return
        fresh = snap["age"] is not None and snap["age"] < 0.5
        self.status.configure(text="Receiving" if fresh else "Signal lost")
        r = snap["raw"]
        self.raw_label.configure(text="Incoming (degrees)  Value 1 %+.0f   Value 2 %+.0f   Value 3 %+.0f" % tuple(r))
        h = self.imu.head()
        if h:
            self.head_label.configure(text="Head  nod %+.0f   turn %+.0f   tilt %+.0f" % h)
        self.seen_label.configure(text="Addresses seen: " + ", ".join(snap["seen"]))


SKEL_BONES = [(3, 2), (2, 4), (2, 8), (2, 1), (1, 0), (0, 12), (0, 16),
              (4, 5), (5, 6), (6, 7), (8, 9), (9, 10), (10, 11),
              (12, 13), (13, 14), (14, 15), (16, 17), (17, 18), (18, 19)]


class KinectTab:
    """Kinect v1 tilt + colour camera settings, through the small kinect_ctl.exe helper."""

    NICE = {"BacklightCompensationMode": "Backlight compensation", "PowerLineFrequency": "Power line frequency",
            "WhiteBalance": "White balance", "AutoWhiteBalance": "Auto white balance",
            "AutoExposure": "Auto exposure", "ExposureTime": "Exposure time", "FrameInterval": "Frame interval"}

    def __init__(self, root, parent, face_app):
        import queue
        self.root, self.face_app = root, face_app
        self.proc = None
        self.q = queue.Queue()
        self.built = None          # tuple of setting names the UI was built for
        self.widgets = {}
        self.quiet = False         # True while we push values into widgets (so they don't re-send)
        self.exe = os.path.join(HERE, "kinect_ctl.exe")
        pad = 12

        card = ft.App.card(face_app, parent, "Kinect (v1 / Xbox 360)")
        card.pack(fill="x", padx=pad, pady=(pad, 0))
        ttk.Label(card, text="The Kinect can only be used by one program at a time. Press Connect to adjust it here, "
                  "then Disconnect before you start Garry's Mod. The tilt stays where you leave it; "
                  "the camera settings may reset when the sensor is released.",
                  style="Muted.TLabel", wraplength=560, justify="left").pack(anchor="w")
        row = ttk.Frame(card, style="Card.TFrame")
        row.pack(fill="x", pady=(8, 0))
        self.go = ttk.Button(row, text="Connect", style="Accent.TButton", command=self.toggle)
        self.go.pack(side="left")
        self.status = ttk.Label(row, text="Not connected", style="Muted.TLabel")
        self.status.pack(side="left", padx=10)

        pcard = ft.App.card(face_app, parent, "Camera view")
        pcard.pack(fill="x", padx=pad, pady=(pad, 0))
        self.prev_var = tk.IntVar(value=1)
        ttk.Checkbutton(pcard, text="Live preview (only while connected)", variable=self.prev_var,
                        command=self.apply_preview).pack(anchor="w")
        self.prev_img = None
        self.prev_mtime = 0
        self.prev_path = os.path.join(__import__("tempfile").gettempdir(), "gmmt_kinect_preview.png")
        self.prev_label = tk.Label(pcard, bg="#0d0e11", fg="#888888", width=320, height=240,
                                   text="No picture", compound="center")
        self.prev_label.pack(pady=(6, 0))
        self.prev_label.config(width=44, height=15)

        tcard = ft.App.card(face_app, parent, "Tilt")
        tcard.pack(fill="x", padx=pad, pady=(pad, 0))
        trow = ttk.Frame(tcard, style="Card.TFrame")
        trow.pack(fill="x")
        self.tilt_var = tk.DoubleVar(value=0)
        self.tilt = ttk.Scale(trow, from_=-27, to=27, variable=self.tilt_var, length=360,
                              command=lambda v: self.tilt_lbl.config(text="%d°" % round(float(v))))
        self.tilt.pack(side="left")
        self.tilt.bind("<ButtonRelease-1>", lambda e: self.send("tilt %d" % round(self.tilt_var.get())))
        self.tilt_lbl = ttk.Label(trow, text="0°", style="Card.TLabel", width=5)
        self.tilt_lbl.pack(side="left", padx=8)
        ttk.Button(trow, text="Level (0°)", command=lambda: self.send("tilt 0")).pack(side="left")
        self.accel = ttk.Label(tcard, text="", style="Muted.TLabel")
        self.accel.pack(anchor="w", pady=(4, 0))

        self.cam = ft.App.card(face_app, parent, "Colour camera")
        self.cam.pack(fill="x", padx=pad, pady=(pad, 0))
        self.cam_note = ttk.Label(self.cam, text="Connect to load the camera settings.", style="Muted.TLabel")
        self.cam_note.pack(anchor="w")
        self.cam_grid = ttk.Frame(self.cam, style="Card.TFrame")
        self.cam_grid.pack(fill="x")
        ttk.Button(self.cam, text="Reset all to defaults", command=self.reset_all).pack(anchor="w", pady=(8, 0))

        if not os.path.exists(self.exe):
            self.status.config(text="kinect_ctl.exe not found - run build_kinect_ctl.bat first")

    # ---- helper process -------------------------------------------------
    def start_proc(self):
        import subprocess, threading
        if self.proc and self.proc.poll() is None:
            return True
        if not os.path.exists(self.exe):
            self.status.config(text="kinect_ctl.exe not found - run build_kinect_ctl.bat first")
            return False
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        try:
            self.proc = subprocess.Popen([self.exe], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                         stderr=subprocess.STDOUT, cwd=HERE, creationflags=flags,
                                         universal_newlines=True, bufsize=1)
        except Exception as e:
            self.status.config(text="Could not start helper: %s" % e)
            return False

        def reader(p):
            for line in p.stdout:
                self.q.put(line.strip())
            self.q.put(None)
        threading.Thread(target=reader, args=(self.proc,), daemon=True).start()
        return True

    def send(self, cmd):
        if not (self.proc and self.proc.poll() is None):
            return
        try:
            self.proc.stdin.write(cmd + "\n")
            self.proc.stdin.flush()
        except Exception:
            pass

    def apply_preview(self):
        self.send("preview %d" % self.prev_var.get())

    def refresh_preview(self):
        if self.go.cget("text") != "Disconnect" or not self.prev_var.get():
            return
        try:
            m = os.path.getmtime(self.prev_path)
            if m == self.prev_mtime:
                return
            img = tk.PhotoImage(file=self.prev_path).subsample(2, 2)
        except Exception:
            return
        self.prev_mtime = m
        self.prev_img = img
        self.prev_label.config(image=img, text="", width=320, height=240)

    def toggle(self):
        if self.go.cget("text") == "Disconnect":
            self.disconnect()
        elif self.start_proc():
            self.status.config(text="Connecting...")
            self.send("open 0")
            self.send("preview %d" % self.prev_var.get())

    def disconnect(self):
        self.send("close")
        self.go.config(text="Connect")
        self.prev_img = None
        self.prev_label.config(image="", text="No picture", width=44, height=15)
        self.status.config(text="Disconnected - the Kinect is free for Garry's Mod")
        self.accel.config(text="")

    def stop(self):
        if self.proc and self.proc.poll() is None:
            self.send("quit")
            try:
                self.proc.wait(timeout=2)
            except Exception:
                self.proc.kill()

    # ---- replies -------------------------------------------------------
    def poll(self):
        import json
        self.refresh_preview()
        while True:
            try:
                line = self.q.get_nowait()
            except Exception:
                return
            if line is None:
                self.go.config(text="Connect")
                self.status.config(text="Helper closed")
                continue
            try:
                msg = json.loads(line)
            except ValueError:
                self.status.config(text=line[:120])
                continue
            if not msg.get("ok", True):
                self.status.config(text=msg.get("error", "Error"))
            elif msg.get("open"):
                self.apply_status(msg)

    def apply_status(self, m):
        self.go.config(text="Disconnect")
        self.status.config(text="Connected (%s)" % m.get("status", "?"))
        self.quiet = True
        try:
            if "tiltMin" in m:
                self.tilt.config(from_=m["tiltMin"], to=m["tiltMax"])
            if "tilt" in m:
                self.tilt_var.set(m["tilt"])
                self.tilt_lbl.config(text="%d°" % m["tilt"])
            if m.get("accel"):
                a = m["accel"]
                self.accel.config(text="Accelerometer  x %.2f   y %.2f   z %.2f  (1.0 = gravity)" % tuple(a))
            cam = m.get("camera")
            if not cam:
                self.cam_note.config(text="This sensor reports no colour camera settings.")
                return
            names = tuple(c["name"] for c in cam)
            if names != self.built:
                self.build_camera(cam)
                self.built = names
            self.cam_note.config(text="")
            for c in cam:
                self.set_widget(c)
        finally:
            self.quiet = False

    def build_camera(self, cam):
        for w in self.cam_grid.winfo_children():
            w.destroy()
        self.widgets = {}
        for r, c in enumerate(cam):
            name = c["name"]
            ttk.Label(self.cam_grid, text=self.NICE.get(name, name), style="Card.TLabel", width=24).grid(
                row=r, column=0, sticky="w", pady=2)
            if c["kind"] == "bool":
                v = tk.IntVar()
                cb = ttk.Checkbutton(self.cam_grid, variable=v,
                                     command=lambda n=name, v=v: (not self.quiet) and self.send("set %s %d" % (n, v.get())))
                cb.grid(row=r, column=1, sticky="w")
                self.widgets[name] = ("bool", v, None)
            elif c["kind"] == "enum":
                v = tk.StringVar()
                cbx = ttk.Combobox(self.cam_grid, textvariable=v, state="readonly", values=c.get("options", []), width=22)
                cbx.grid(row=r, column=1, sticky="w")
                cbx.bind("<<ComboboxSelected>>", lambda e, n=name, v=v: self.send("set %s %s" % (n, v.get())))
                self.widgets[name] = ("enum", v, None)
            else:
                lo, hi = c.get("min"), c.get("max")
                if lo is None or hi is None or lo == hi:
                    lo, hi = 0, 1
                v = tk.DoubleVar(value=lo)
                lbl = ttk.Label(self.cam_grid, text="", style="Card.TLabel", width=9)
                s = ttk.Scale(self.cam_grid, from_=lo, to=hi, variable=v, length=260,
                              command=lambda val, l=lbl: l.config(text="%.3g" % float(val)))
                s.grid(row=r, column=1, sticky="w")
                lbl.grid(row=r, column=2, padx=6)
                s.bind("<ButtonRelease-1>", lambda e, n=name, v=v: self.send("set %s %s" % (n, repr(v.get()))))
                self.widgets[name] = ("num", v, lbl)
            ttk.Button(self.cam_grid, text="Default", width=8,
                       command=lambda n=name: self.send("set %s default" % n)).grid(row=r, column=3, padx=4)

    def set_widget(self, c):
        w = self.widgets.get(c["name"])
        if not w or c.get("value") is None:
            return
        kind, v, lbl = w
        if kind == "bool":
            v.set(1 if c["value"] else 0)
        elif kind == "enum":
            v.set(c["value"])
        else:
            v.set(c["value"])
            lbl.config(text="%.3g" % float(c["value"]))

    def reset_all(self):
        for name in list(self.widgets):
            self.send("set %s default" % name)


def main():
    settings = ft.load_settings()
    if not os.path.isdir(settings["data_dir"]):
        guess = ft.guess_data_dir()
        if guess:
            settings["data_dir"] = guess

    root = tk.Tk()
    root.title("GMMT - Garry's Mod Motion Tracker")
    root.configure(bg=ft.BG)
    root.resizable(False, False)

    nb = ttk.Notebook(root)
    nb.pack(fill="both", expand=True)
    face_tab = ttk.Frame(nb)
    finger_tab = ttk.Frame(nb)
    phone_tab = ttk.Frame(nb)
    kinect_tab = ttk.Frame(nb)
    nb.add(face_tab, text="  Face  ")
    nb.add(finger_tab, text="  Fingers  ")
    nb.add(phone_tab, text="  Phone  ")
    nb.add(kinect_tab, text="  Kinect  ")

    face_app = ft.App(root, settings, False, parent=face_tab, standalone=False)
    # the notebook needs matching colours (style is created by App)
    style = ttk.Style(root)
    style.configure("TNotebook", background=ft.BG, borderwidth=0)
    style.configure("TNotebook.Tab", background=ft.EDGE, foreground=ft.TEXT, padding=(14, 6))
    style.map("TNotebook.Tab", background=[("selected", ft.PANEL)])

    fingers = FingerTab(root, finger_tab, face_app, settings)
    phone = PhoneTab(root, phone_tab, face_app, settings)
    kinect = KinectTab(root, kinect_tab, face_app)

    def poll_fingers():
        try:
            fingers.poll()
            phone.poll()
            kinect.poll()
        finally:
            root.after(50, poll_fingers)
    root.after(50, poll_fingers)

    def on_close():
        face_app.persist()
        face_app.stop_tracker()
        fingers.stop()
        phone.save()
        phone.stop()
        kinect.stop()
        ft.save_settings(settings)
        root.destroy()
    root.protocol("WM_DELETE_WINDOW", on_close)
    root.mainloop()


if __name__ == "__main__":
    main()
