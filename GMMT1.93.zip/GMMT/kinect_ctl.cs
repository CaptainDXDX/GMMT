// kinect_ctl.cs - tiny Kinect v1 control helper for GMMT.
// Build once with build_kinect_ctl.bat (uses the C# compiler that ships with Windows).
//
// GMMT starts this program and sends it one command per line on stdin; it answers
// each command with one line of JSON on stdout. While it is open it HOLDS the Kinect,
// so GMMT's "Disconnect" button closes it to give the sensor back to Garry's Mod.
//
// Commands:  list | open [index] | close | tilt <degrees> | get | set <Property> <value|default> | preview 0/1 | quit
// While preview is on, the colour picture is saved as gmmt_kinect_preview.png in the temp folder (about 8 per second).
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Globalization;
using System.Reflection;
using System.Text;
using Microsoft.Kinect;

public static class KinectCtl
{
    static KinectSensor sensor;
    static DateTime lastTilt = DateTime.MinValue;
    static bool previewOn = true;
    static DateTime lastFrame = DateTime.MinValue;
    static byte[] pixels;
    static readonly string PreviewPath = Path.Combine(Path.GetTempPath(), "gmmt_kinect_preview.png");

    static void OnColorFrame(object s, ColorImageFrameReadyEventArgs e)
    {
        try
        {
            using (ColorImageFrame f = e.OpenColorImageFrame())
            {
                if (f == null || !previewOn) return;
                if ((DateTime.UtcNow - lastFrame).TotalMilliseconds < 120) return;
                lastFrame = DateTime.UtcNow;
                if (pixels == null || pixels.Length != f.PixelDataLength) pixels = new byte[f.PixelDataLength];
                f.CopyPixelDataTo(pixels);
                using (Bitmap bmp = new Bitmap(f.Width, f.Height, PixelFormat.Format32bppRgb))
                {
                    BitmapData bd = bmp.LockBits(new Rectangle(0, 0, f.Width, f.Height), ImageLockMode.WriteOnly, PixelFormat.Format32bppRgb);
                    System.Runtime.InteropServices.Marshal.Copy(pixels, 0, bd.Scan0, Math.Min(pixels.Length, bd.Stride * f.Height));
                    bmp.UnlockBits(bd);
                    string tmp = PreviewPath + ".tmp";
                    bmp.Save(tmp, ImageFormat.Png);
                    if (File.Exists(PreviewPath)) File.Delete(PreviewPath);
                    File.Move(tmp, PreviewPath);
                }
            }
        }
        catch (Exception) { }
    }
    static readonly CultureInfo Inv = CultureInfo.InvariantCulture;

    static string Esc(string s)
    {
        if (s == null) return "";
        StringBuilder b = new StringBuilder();
        foreach (char c in s)
        {
            if (c == '\\') b.Append("\\\\");
            else if (c == '"') b.Append("\\\"");
            else if (c == '\n') b.Append("\\n");
            else if (c == '\r') { }
            else if (c < 32) b.Append(' ');
            else b.Append(c);
        }
        return b.ToString();
    }

    static string Q(string s) { return "\"" + Esc(s) + "\""; }

    static string Num(double d)
    {
        if (double.IsNaN(d) || double.IsInfinity(d)) return "null";
        return d.ToString("R", Inv);
    }

    static void Reply(string json)
    {
        Console.Out.WriteLine(json);
        Console.Out.Flush();
    }

    static void Fail(string message)
    {
        Reply("{\"ok\":false,\"error\":" + Q(message) + "}");
    }

    static string Sensors()
    {
        StringBuilder b = new StringBuilder("[");
        int n = 0;
        foreach (KinectSensor s in KinectSensor.KinectSensors)
        {
            if (n > 0) b.Append(",");
            b.Append("{\"index\":" + n + ",\"status\":" + Q(s.Status.ToString()) +
                     ",\"id\":" + Q(s.DeviceConnectionId) + "}");
            n++;
        }
        b.Append("]");
        return b.ToString();
    }

    static object Settings()
    {
        if (sensor == null) return null;
        try { return sensor.ColorStream.CameraSettings; }
        catch (Exception) { return null; }
    }

    static PropertyInfo Prop(object o, string name)
    {
        return o.GetType().GetProperty(name, BindingFlags.Public | BindingFlags.Instance | BindingFlags.IgnoreCase);
    }

    static string ValueJson(object v)
    {
        if (v == null) return "null";
        if (v is bool) return ((bool)v) ? "true" : "false";
        if (v is Enum) return Q(v.ToString());
        if (v is double) return Num((double)v);
        if (v is float) return Num((double)(float)v);
        if (v is int || v is long || v is short || v is byte) return Convert.ToInt64(v, Inv).ToString(Inv);
        return Q(v.ToString());
    }

    // One camera setting as JSON: its value, and its limits when the SDK provides them.
    static string SettingJson(object settings, PropertyInfo p)
    {
        StringBuilder b = new StringBuilder("{\"name\":" + Q(p.Name));
        Type t = p.PropertyType;
        string kind = t == typeof(bool) ? "bool" : (t.IsEnum ? "enum" : "number");
        b.Append(",\"kind\":" + Q(kind));
        object value = null;
        try { value = p.GetValue(settings, null); }
        catch (Exception ex) { b.Append(",\"readError\":" + Q(ex.InnerException != null ? ex.InnerException.Message : ex.Message)); }
        b.Append(",\"value\":" + ValueJson(value));
        if (t.IsEnum)
        {
            b.Append(",\"options\":[");
            string[] names = Enum.GetNames(t);
            for (int i = 0; i < names.Length; i++) b.Append((i > 0 ? "," : "") + Q(names[i]));
            b.Append("]");
        }
        string[] limits = new string[] { "Minimum", "Maximum", "Default" };
        string[] keys = new string[] { "min", "max", "default" };
        for (int i = 0; i < limits.Length; i++)
        {
            PropertyInfo lp = Prop(settings, limits[i] + p.Name);
            if (lp == null) continue;
            try { b.Append(",\"" + keys[i] + "\":" + ValueJson(lp.GetValue(settings, null))); }
            catch (Exception) { }
        }
        b.Append("}");
        return b.ToString();
    }

    static bool IsSetting(PropertyInfo p)
    {
        if (!p.CanRead || !p.CanWrite) return false;
        if (p.GetIndexParameters().Length != 0) return false;
        Type t = p.PropertyType;
        return t == typeof(bool) || t == typeof(double) || t == typeof(int) || t == typeof(long) || t.IsEnum;
    }

    static string StatusJson()
    {
        StringBuilder b = new StringBuilder("{\"ok\":true,\"open\":" + (sensor != null ? "true" : "false"));
        if (sensor != null)
        {
            b.Append(",\"status\":" + Q(sensor.Status.ToString()));
            try
            {
                b.Append(",\"tilt\":" + sensor.ElevationAngle + ",\"tiltMin\":" + sensor.MinElevationAngle +
                         ",\"tiltMax\":" + sensor.MaxElevationAngle);
            }
            catch (Exception ex) { b.Append(",\"tiltError\":" + Q(ex.Message)); }
            try
            {
                Vector4 a = sensor.AccelerometerGetCurrentReading();
                b.Append(",\"accel\":[" + Num(a.X) + "," + Num(a.Y) + "," + Num(a.Z) + "]");
            }
            catch (Exception) { }
            object settings = Settings();
            if (settings == null)
            {
                b.Append(",\"camera\":null");
            }
            else
            {
                b.Append(",\"camera\":[");
                int n = 0;
                foreach (PropertyInfo p in settings.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance))
                {
                    if (!IsSetting(p)) continue;
                    if (n++ > 0) b.Append(",");
                    b.Append(SettingJson(settings, p));
                }
                b.Append("]");
            }
        }
        b.Append("}");
        return b.ToString();
    }

    static void CloseSensor()
    {
        if (sensor == null) return;
        try { sensor.ColorFrameReady -= OnColorFrame; } catch (Exception) { }
        try { sensor.Stop(); } catch (Exception) { }
        sensor = null;
    }

    static void Open(int index)
    {
        CloseSensor();
        int n = 0;
        KinectSensor found = null;
        foreach (KinectSensor s in KinectSensor.KinectSensors)
        {
            if (n == index) { found = s; break; }
            n++;
        }
        if (found == null) { Fail("No Kinect with index " + index + ". Is it plugged in and powered?"); return; }
        if (found.Status != KinectStatus.Connected)
        {
            Fail("The Kinect reports status '" + found.Status + "' (it must be 'Connected'). Close anything else using it, then try again.");
            return;
        }
        try
        {
            // the colour stream has to be on for the camera settings to be reachable
            found.ColorStream.Enable(ColorImageFormat.RgbResolution640x480Fps30);
            found.ColorFrameReady += OnColorFrame;
            found.Start();
            sensor = found;
        }
        catch (Exception ex)
        {
            Fail("Could not open the Kinect: " + ex.Message + " (another program may already be using it)");
            return;
        }
        Reply(StatusJson());
    }

    static void Tilt(string arg)
    {
        if (sensor == null) { Fail("Not connected."); return; }
        double deg;
        if (!double.TryParse(arg, NumberStyles.Float, Inv, out deg)) { Fail("Tilt needs a number of degrees."); return; }
        double wait = 1.6 - (DateTime.UtcNow - lastTilt).TotalSeconds;
        if (wait > 0) System.Threading.Thread.Sleep((int)(wait * 1000)); // the motor must not be commanded too often
        int target = (int)Math.Round(deg);
        if (target < sensor.MinElevationAngle) target = sensor.MinElevationAngle;
        if (target > sensor.MaxElevationAngle) target = sensor.MaxElevationAngle;
        try { sensor.ElevationAngle = target; }
        catch (Exception ex) { Fail("Tilt failed: " + ex.Message); return; }
        lastTilt = DateTime.UtcNow;
        System.Threading.Thread.Sleep(700);
        Reply(StatusJson());
    }

    static void Set(string arg)
    {
        if (sensor == null) { Fail("Not connected."); return; }
        object settings = Settings();
        if (settings == null) { Fail("This sensor exposes no camera settings."); return; }
        int sp = arg.IndexOf(' ');
        if (sp < 0) { Fail("Usage: set <Property> <value|default>"); return; }
        string name = arg.Substring(0, sp).Trim();
        string val = arg.Substring(sp + 1).Trim();
        PropertyInfo p = Prop(settings, name);
        if (p == null || !IsSetting(p)) { Fail("Unknown camera setting '" + name + "'."); return; }
        try
        {
            object v;
            if (val.ToLowerInvariant() == "default")
            {
                PropertyInfo dp = Prop(settings, "Default" + p.Name);
                if (dp == null) { Fail("'" + p.Name + "' has no default value."); return; }
                v = dp.GetValue(settings, null);
            }
            else if (p.PropertyType == typeof(bool)) v = (val == "1" || val.ToLowerInvariant() == "true");
            else if (p.PropertyType.IsEnum) v = Enum.Parse(p.PropertyType, val, true);
            else if (p.PropertyType == typeof(double)) v = double.Parse(val, NumberStyles.Float, Inv);
            else if (p.PropertyType == typeof(int)) v = (int)Math.Round(double.Parse(val, NumberStyles.Float, Inv));
            else v = (long)Math.Round(double.Parse(val, NumberStyles.Float, Inv));
            p.SetValue(settings, v, null);
        }
        catch (Exception ex)
        {
            Exception inner = ex.InnerException != null ? ex.InnerException : ex;
            Fail("Could not set " + name + ": " + inner.Message);
            return;
        }
        Reply(StatusJson());
    }

    static bool Handle(string line)
    {
        if (line.Length == 0) return true;
        string cmd = line, arg = "";
        int sp = line.IndexOf(' ');
        if (sp > 0) { cmd = line.Substring(0, sp); arg = line.Substring(sp + 1).Trim(); }
        switch (cmd.ToLowerInvariant())
        {
            case "list": Reply("{\"ok\":true,\"sensors\":" + Sensors() + "}"); break;
            case "open":
                {
                    int idx = 0;
                    if (arg.Length > 0) int.TryParse(arg, out idx);
                    Open(idx);
                    break;
                }
            case "close": CloseSensor(); Reply("{\"ok\":true,\"open\":false}"); break;
            case "tilt": Tilt(arg); break;
            case "preview": previewOn = (arg == "1"); Reply("{\"ok\":true,\"preview\":" + (previewOn ? "true" : "false") + "}"); break;
            case "get": Reply(StatusJson()); break;
            case "set": Set(arg); break;
            case "quit": return false;
            default: Fail("Unknown command '" + cmd + "'."); break;
        }
        return true;
    }

    public static int Main(string[] args)
    {
        Reply("{\"ok\":true,\"ready\":true}");
        try
        {
            string line;
            while ((line = Console.In.ReadLine()) != null)
            {
                bool go = true;
                try { go = Handle(line.Trim()); }
                catch (Exception ex) { Fail(ex.GetType().Name + ": " + ex.Message); }
                if (!go) break;
            }
        }
        finally
        {
            CloseSensor();
        }
        return 0;
    }
}
